# -*- coding: utf-8 -*-
isUnique = False
compId = 'Dialogue'
LastVersion = [
	0,
	1,
	0
]
version = [
	0,
	1,
	0
]
dataDict = {
	'3a3568bc-86c4-49f8-a9e0-4af88e77ff70': {
		'appearCondition': 3,
		'compositions': [
			{
				'content': '没想到这么快就出成果啦！这枚海洋之心好好保留，保卫海洋安全！',
				'select': [
					{
						'option': {
							'continue': False,
							'done': '合成海洋之心',
							'shift': '',
							'todo': ''
						},
						'reply': '确认后再次找鹦鹉对话'
					}
				]
			}
		],
		'dialogueName': '鹦鹉——交付任务2',
		'npcEntityId': '-141733920752',
		'postAppearDoing': '',
		'postAppearDone': '合成海洋之心',
		'postAppearTodo': '',
		'uuid': '3a3568bc-86c4-49f8-a9e0-4af88e77ff70'
	},
	'530e56de-3591-4baa-be35-b240fd1a8c6b': {
		'appearCondition': 2,
		'compositions': [
			{
				'content': '现在存在一个难题：据史书记载将粘液球与某种岩浆物质混合并用某铁质器具打造即可获得宝贵的岩浆膏！快去试试吧！',
				'select': [
					{
						'option': {
							'continue': False,
							'done': '',
							'shift': '',
							'todo': '合成岩浆膏'
						},
						'reply': '准备好接受挑战啦！'
					}
				]
			}
		],
		'dialogueName': '鹦鹉——领取任务3',
		'npcEntityId': '-141733920752',
		'postAppearDoing': '',
		'postAppearDone': '',
		'postAppearTodo': '合成岩浆膏',
		'uuid': '530e56de-3591-4baa-be35-b240fd1a8c6b'
	},
	'5cb2a786-e899-4d98-9aef-4a6d309899c7': {
		'appearCondition': 3,
		'compositions': [
			{
				'content': '今天的第一个科研任务完成啦！祝贺！这把金剑希望能够保你安全！',
				'select': [
					{
						'option': {
							'continue': False,
							'done': '合成金剑',
							'shift': '',
							'todo': ''
						},
						'reply': '确认后再次找鹦鹉对话'
					}
				]
			}
		],
		'dialogueName': '鹦鹉——交付任务1',
		'npcEntityId': '-141733920752',
		'postAppearDoing': '',
		'postAppearDone': '合成金剑',
		'postAppearTodo': '',
		'uuid': '5cb2a786-e899-4d98-9aef-4a6d309899c7'
	},
	'698bbff0-b01c-41d5-88e7-e70a5548822c': {
		'appearCondition': 0,
		'compositions': [
			{
				'content': '学士：猫咪，不要害怕。你的小爪子真可爱呀，我抬起来亲上一口！瞧，你恼羞地看着我，也许通人性呢。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '学士：不能弃它于荒外，我抱去好好照顾。',
				'select': [
					{
						'option': {
							'continue': False,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '走到光柱解救猫咪'
					}
				]
			}
		],
		'dialogueName': '猫——解救',
		'npcEntityId': '-141733920755',
		'postAppearDoing': '',
		'postAppearDone': '',
		'postAppearTodo': '',
		'uuid': '698bbff0-b01c-41d5-88e7-e70a5548822c'
	},
	'69e9c86a-f577-4ec7-af6b-07f0b8882acb': {
		'appearCondition': 3,
		'compositions': [
			{
				'content': '恭喜你完成了今日份的科研任务！快进到下一步探险吧！',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '结束'
					}
				]
			},
			{
				'content': '学士：哎呀！一直沉迷科研忘记了，我去看看猫猫怎么样了，它好像一直待在【地窖旁边的草地那】',
				'select': [
					{
						'option': {
							'continue': False,
							'done': '合成岩浆膏',
							'shift': '',
							'todo': ''
						},
						'reply': '去找找'
					}
				]
			}
		],
		'dialogueName': '鹦鹉——交付任务3',
		'npcEntityId': '-141733920752',
		'postAppearDoing': '',
		'postAppearDone': '合成岩浆膏',
		'postAppearTodo': '',
		'uuid': '69e9c86a-f577-4ec7-af6b-07f0b8882acb'
	},
	'99106722-d804-4558-9b12-703bde01544a': {
		'appearCondition': 2,
		'compositions': [
			{
				'content': 'Hi there！我是你的学术使者鹦·聪明伶俐·鹉，今日份的科研任务快来领取吧！据说金石和木剑可以合成能够保卫你人生安全的金剑噢！',
				'select': [
					{
						'option': {
							'continue': False,
							'done': '',
							'shift': '',
							'todo': '合成金剑'
						},
						'reply': '收到！这就去办！'
					}
				]
			}
		],
		'dialogueName': '鹦鹉——领取任务1',
		'npcEntityId': '-141733920752',
		'postAppearDoing': '',
		'postAppearDone': '',
		'postAppearTodo': '合成金剑',
		'uuid': '99106722-d804-4558-9b12-703bde01544a'
	},
	'b164e6ad-f72a-4386-bd25-632344fe66ed': {
		'appearCondition': 0,
		'compositions': [
			{
				'content': '魔鬼：  这是一个过路的村庄，我们可以在此地稍作歇息。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '同意'
					},
					{
						'option': {
							'continue': False,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '拒绝'
					}
				]
			},
			{
				'content': '学士：    据我彻夜研读反派教科书，这家村庄刚刚好，他们前不久还闹过旱灾。我可以佯装魔术师，借你的力量加重旱情。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '学士：    等我的恶名远扬这片大陆，便会有正义的神官前来感化我，这时我只需要佯装打动，便可获得他的心。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：    你确定神官是来和你谈恋爱的，不是来用光明魔法把你挫骨扬灰的吗？',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '让魔鬼施展魔法'
					}
				]
			},
			{
				'content': '学士：    魔鬼阁下，请施展你的魔法，让干旱降临这座村庄。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：天气不敢违抗地狱之子的命令，然而需要浓郁的元素才能施展魔法。学士，可否收集风、火、水、土四元素之物，再将它们带给我？',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '我该如何收集呢？'
					}
				]
			},
			{
				'content': '魔鬼：看到不远处的【火精灵】了吗，攻击它们就可以获得火元素、土元素的物品。水元素能从【背包中的水瓶】中得到。风无影无形，但是【羽毛】可以记录它们的痕迹。获得四元素物品，再前往工具台将它们合成为元素之书，我可以利用【元素之书】召唤魔法。',
				'select': [
					{
						'option': {
							'continue': False,
							'done': '',
							'shift': '',
							'todo': '收集元素'
						},
						'reply': '小事一桩。'
					}
				]
			}
		],
		'dialogueName': '魔鬼——领取任务',
		'npcEntityId': '-231928233978',
		'postAppearDoing': '收集元素',
		'postAppearDone': '',
		'postAppearTodo': '',
		'uuid': 'b164e6ad-f72a-4386-bd25-632344fe66ed'
	},
	'b3907cd4-a516-4092-84a7-c64095f8197d': {
		'appearCondition': 3,
		'compositions': [
			{
				'content': '学士：   我已经合成了元素之书，请施展咒语吧！',
				'select': [
					{
						'option': {
							'continue': False,
							'done': '收集元素',
							'shift': '',
							'todo': ''
						},
						'reply': '确认后再次找魔鬼对话'
					}
				]
			}
		],
		'dialogueName': '魔鬼——交付任务',
		'npcEntityId': '-231928233978',
		'postAppearDoing': '',
		'postAppearDone': '收集元素',
		'postAppearTodo': '',
		'uuid': 'b3907cd4-a516-4092-84a7-c64095f8197d'
	},
	'b8b6998e-f0b4-41bc-b757-7863307b7ca4': {
		'appearCondition': 0,
		'compositions': [
			{
				'content': '学士：上帝！好呛人的烟雾，猫猫去哪里了！啊，雾气消散了……',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：何至喧哗？',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '这是什么玩意'
					}
				]
			},
			{
				'content': '学士：我看到了什么情形？我又是否身处梦境，黑猫消失在雾气中，我竟然带了个魔鬼回家！ ',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': 'oh no'
					}
				]
			},
			{
				'content': '魔鬼：不错，我正是地狱之子，我的先祖是那大名鼎鼎的梅菲斯特，冥界服从我母亲的统治。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：你无需呼唤因库布斯，那位神明早已沉睡。四精灵咒亦不能伤害我，我恢复了真身，五芒星阵不过儿戏，休想把我赶回黑夜。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '你在说什么'
					}
				]
			},
			{
				'content': '魔鬼：啊，浮士德的后辈竟落得如此地步。我今日前来，是要使你的灵魂堕入地狱，再也听不见神明的圣谕。你的灵魂留作抵押，你的鲜血签下契约，我将让你见识人所未见，享人所未享。 ',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '还没缓过劲来'
					}
				]
			},
			{
				'content': '学士：魔鬼阁下，可否变回小猫的样子，趴在我怀里。让我揉着你的毛，一切再细细商议？ ',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：何等放肆！你先前对我又亲又抱，如今还想我趴在你怀里！',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：来自地狱深沟的黑火——',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '饶命呐！'
					}
				]
			},
			{
				'content': '学士：魔鬼阁下饶命哇！交易前有件事想问清楚，为何你独独选中了我，难道我的灵魂世间难有，无可挑剔？',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：不是，先前押送灵魂，我不过稍稍描述了一下地狱的美景，他们都死命跑去了天堂，请求上帝宽恕。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '认真聆听'
					}
				]
			},
			{
				'content': '魔鬼：母亲一怒之下命我在人世诱拐一个灵魂。否则便将冥界给我那野心勃勃的姐姐。我临行前和姐姐打了一架，她把我变成了猫崽，一脚踹到了你们面前。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '认真聆听'
					}
				]
			},
			{
				'content': '魔鬼：你想要什么，世间难享的珍肴美食？',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '学士：不必啦，麦当劳一个电话送到家，黑椒牛扒大汉堡，酥辣黄金小鸡腿，还有酥甜绝赞雪糕，套餐只要99.8！',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：卧槽买一份！那么，女巫丹房坩埚里的青春药，重焕青春是世人贪念。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '学士：学士我年方二八，正青春好年华，何需你那青春药！',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：此人莫非无欲无求，她的灵魂纯洁无辜，注定是上帝的使臣。还有什么能诱惑她？',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '学士：魔鬼阁下你听我说，有件事实在难启齿，二八春秋转眼逝，真爱至今却难寻。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '你这么宅还想有真爱！'
					}
				]
			},
			{
				'content': '魔鬼：不，学士潜心学问，是世人标榜。这桩请求我早已料到，明日清早就出发，我们动身前往希腊，一点小小的魔法，一段美好的邂逅，来自地狱深沟的魔鬼最真挚的服务，你值得拥有。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '学士：现在已经不兴这个了，大家都爱迷人的反派。我这有本反派养成教科书，我们可以细细研读一番。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '等魔鬼说话'
					}
				]
			},
			{
				'content': '学士：魔鬼魔鬼你为何不说话，在你眼前晃也不理我，你脸好烫啊，怎么别过头去了？',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：别挨我那么近呀白痴！',
				'select': [
					{
						'option': {
							'continue': False,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '从传送门离开'
					}
				]
			}
		],
		'dialogueName': '魔鬼现真身',
		'npcEntityId': '-223338299384',
		'postAppearDoing': '',
		'postAppearDone': '',
		'postAppearTodo': '',
		'uuid': 'b8b6998e-f0b4-41bc-b757-7863307b7ca4'
	},
	'c3f629ba-6264-47e4-99a5-3bf0379dde34': {
		'appearCondition': 2,
		'compositions': [
			{
				'content': '传说中青金石经过一定的方法可以合成宝贵的海洋之心，为海洋安全保驾护航。请你去探索海洋之心的获得方法吧！！！',
				'select': [
					{
						'option': {
							'continue': False,
							'done': '',
							'shift': '',
							'todo': '合成海洋之心'
						},
						'reply': 'get！'
					}
				]
			}
		],
		'dialogueName': '鹦鹉——领取任务2',
		'npcEntityId': '-141733920752',
		'postAppearDoing': '',
		'postAppearDone': '回家',
		'postAppearTodo': '合成海洋之心',
		'uuid': 'c3f629ba-6264-47e4-99a5-3bf0379dde34'
	},
	'e26a2ec1-877c-4694-b09a-86f290d641a6': {
		'appearCondition': 2,
		'compositions': [
			{
				'content': '魔鬼：    四精灵啊，听从地狱之子的命令。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：    哗哗地汇合吧，水精！流星般闪耀吧，风精！沉重的力量吧，土精！ ',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '抬头'
					}
				]
			},
			{
				'content': '学士：    啊，天地都颤抖起来了，乌云密布，雷声滚滚……等等，怎么开始下雨了？',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：    ……我好像忘了召唤火精。我平常也就扔扔火球玩，没用过这么高等的咒语。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：    听村民的声音，他们在赞颂我们带来的雨露，还要将我们的荣誉传遍四海。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '你太坑了吧！'
					}
				]
			},
			{
				'content': '学士：    什么，你太坑了吧，我体验不了酷酷的反派生活啦。救世主的套路不都是，为拯救黎民苍生而牺牲爱情的吗。 这样一想，我可能要单身一辈子了啊！',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：   我听到了魔龙痛苦的哀嚎。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '！！'
					}
				]
			},
			{
				'content': '学士：  我是在哀嚎，但也不要把我比喻成魔龙吧！ ',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：   不，我说的是地狱深处的魔龙，我要回去看看，是不是我那野心勃勃的姐姐又做了什么。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：    你先去女巫家里等我，我曾为她的屋子施下过结界咒语，那是这个村庄最安全的地方。你与我签订了契约，也可以自由出入。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '魔鬼：    记住，女巫的爱好是【闪亮发光的东西】，她们喜欢用璀璨的宝石装点居所，喜欢设置与【时间】有关的机关。还有，在我离开的这段时间，不要让任何人进来。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '女巫！'
					}
				]
			},
			{
				'content': '学士：    哇哦！女巫！她们会用酷酷的法术召唤亡灵吗？',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '听魔鬼回答'
					}
				]
			},
			{
				'content': '魔鬼：   女巫其实分很多派系，只有亡灵女巫才会召唤法术。这个女巫是物理系的，她平常的爱好是做TNT和炸药。这些我回来再和你细说。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '魔鬼离开'
					}
				]
			},
			{
				'content': '学士：    等等……她家在哪里来着？魔鬼你回来！\n',
				'select': [
					{
						'option': {
							'continue': False,
							'done': '',
							'shift': '',
							'todo': '找到女巫家'
						},
						'reply': '去找女巫家'
					}
				]
			}
		],
		'dialogueName': '魔鬼——去女巫家',
		'npcEntityId': '-231928233978',
		'postAppearDoing': '',
		'postAppearDone': '收集元素',
		'postAppearTodo': '找到女巫家',
		'uuid': 'e26a2ec1-877c-4694-b09a-86f290d641a6'
	},
	'e26b3aea-bb1a-4c0e-92d8-ca647dd91b69': {
		'appearCondition': 0,
		'compositions': [
			{
				'content': '学士：多么美妙的好景！云雀鸣啭在头顶，清歌缭绕入青冥。忘却世俗的烦恼，此刻我们身处天堂。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '确实'
					}
				]
			},
			{
				'content': '助手：学士，虽然不想扫您的兴，但您还记得这周要写论文吗？',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '问题不大'
					}
				]
			},
			{
				'content': '学士：自然惠赠你教义，你的灵智将豁然洞开，星辰的运行，精灵之语也将明白。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '助手：您说的听起来很有道理，但教授已经催了您很多遍了。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '学士：你看这奥秘无穷的大自然，最能激发人的灵感。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '助手：……您写深度学习与神经网络，关大自然屁事啊！',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '学士：好心的阁下求求情，我ddl实在赶不完啦。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '呜呜'
					}
				]
			},
			{
				'content': '助手：哼，除非天降奇遇，说什么也不能让您溜走了。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '学士：我亲爱的助手，你快看前边，海水中流淌着熔浆，冷却的熔浆凝成黑岩，好像天空里的一座孤岛，好像王冠上黯淡的宝石。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '远眺'
					}
				]
			},
			{
				'content': '助手：您不要说奇怪的话混淆视听，我是不会再上当的。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '瞧上一瞧'
					}
				]
			},
			{
				'content': '学士：是真的，你看，熔浆中有一只受困的猫咪，我要去救它出来。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '有猫猫！'
					}
				]
			},
			{
				'content': '助手：天哪，我的眼前是何景象。学士，这件事过于蹊跷，请您不要靠近那里。要知道，黑猫从来都是不祥之兆，永不熄灭的火更是地狱独有。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '我要去救它出来。'
					}
				]
			},
			{
				'content': '助手：那只黑猫正在看着我们，它像个魔鬼，背脊好有黑火燃烧，或许正是它带来了这些熔岩。',
				'select': [
					{
						'option': {
							'continue': False,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '我要去救它出来。'
					}
				]
			}
		],
		'dialogueName': '助手解救前',
		'npcEntityId': '-227633266686',
		'postAppearDoing': '',
		'postAppearDone': '',
		'postAppearTodo': '',
		'uuid': 'e26b3aea-bb1a-4c0e-92d8-ca647dd91b69'
	},
	'e2af6363-c937-4473-999b-0037e18061e1': {
		'appearCondition': 0,
		'compositions': [
			{
				'content': '学士：房间空空荡荡，女巫似乎已经外出很久。魔鬼也一去不返。我的肚子现在咕咕作响，饥肠辘辘，就快永别人世了。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '看向神官'
					}
				]
			},
			{
				'content': '学士：等等，我看到了什么，外面站着一碗香喷喷的饭菜，不，外面站着一个穿雪白长袍的金发神官，端着饭菜正朝我微笑。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '好好吃的神官！'
					},
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '好好看的佳肴！'
					}
				]
			},
			{
				'content': '神官：尊贵的救世主阁下，我听闻您拯救了这片大陆，特地慕名前来拜见。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '见见她也没关系吧！'
					}
				]
			},
			{
				'content': '学士：她的声音真是悦耳动听，等等，神官是个妹子吗！',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '神官掐住学士脖子'
					}
				]
			},
			{
				'content': '学士：为什么要突然掐住我的脖子！我还没有成为反派哇！',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '此时魔鬼出现'
					}
				]
			},
			{
				'content': '旁白：[空气里弥漫开雾气，魔鬼从空气中走出，神官笑吟吟地与之对峙]',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '看向魔鬼'
					}
				]
			},
			{
				'content': '魔鬼：离她远点！',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '！！'
					}
				]
			},
			{
				'content': '姐姐：好久不见，我亲爱的弟弟。我记得上回见你，你还趴在地上哭着向我求饶。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '她是魔鬼的姐姐！'
					}
				]
			},
			{
				'content': '魔鬼：一点也不想和你追忆往事……',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '继续'
					}
				]
			},
			{
				'content': '姐姐：她就是你要拐的灵魂？如果我现在把她掐死，你便得不到她的灵魂。按照赌约，我将成为冥界的主宰。',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '！'
					}
				]
			},
			{
				'content': '姐姐：这样，你和妈妈就都是我的了！',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '我听到了什么？！'
					}
				]
			},
			{
				'content': '姐姐：让我看看你长进了多少，拔剑吧，弟弟！',
				'select': [
					{
						'option': {
							'continue': True,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '我要去帮魔鬼！'
					}
				]
			},
			{
				'content': '提示：姐姐召唤了补血的魔物，可以利用女巫实验室的TNT炸药，消灭召唤魔物',
				'select': [
					{
						'option': {
							'continue': False,
							'done': '',
							'shift': '',
							'todo': ''
						},
						'reply': '确认'
					}
				]
			}
		],
		'dialogueName': '学士与姐姐',
		'npcEntityId': '-231928233982',
		'postAppearDoing': '',
		'postAppearDone': '',
		'postAppearTodo': '',
		'uuid': 'e2af6363-c937-4473-999b-0037e18061e1'
	}
}
scriptFolderName = 'script_Dialogue'
