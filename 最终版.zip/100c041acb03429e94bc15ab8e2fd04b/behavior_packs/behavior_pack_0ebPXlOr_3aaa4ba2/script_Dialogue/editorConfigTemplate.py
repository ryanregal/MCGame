# -*- coding: utf-8 -*-
compId = "Dialogue"
dataDict = {
	"420b55b1-310e-4285-9383-d29901ad9a0d": {
		"appearCondition": 0,
		"compositions": [],
		"dialogueName": "对话1",
		"npcEntityId": "",
		"postAppearDoing": "",
		"postAppearDone": "",
		"postAppearTodo": "",
		"uuid": "420b55b1-310e-4285-9383-d29901ad9a0d"
	}
}
isUnique = False
name = "<property object at 0x11BAA8A0>"
scriptFolderName = "script_Dialogue"
