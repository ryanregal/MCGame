# -*- coding: utf-8 -*-

import mod.client.extraClientApi as clientApi

# 用来打印规范的log
from .. import logger
from ..clientManager.coroutineMgrGac import CoroutineMgr
from ... import editorConfig
from ...modCommon import dialogueConfig as modConfig

ClientSystem = clientApi.GetClientSystemCls()


class DialogueClientSystem(ClientSystem):
    def __init__(self, namespace, systemName):
        ClientSystem.__init__(self, namespace, systemName)
        logger.info('==== %s ====' % 'init dialogueClientSystem')
        self.listen_event()

        self.m_player_id = clientApi.GetLocalPlayerId()
        self.m_attentive_positions = {}
        self.m_pos_monitor = False
        # 保存ui界面节点
        self.m_dialogue_ui_node = None
        self.m_coroutine_mgr = CoroutineMgr()
        self.m_dialogue_option_handlers = {
            "continue": lambda e: self.m_dialogue_ui_node.next_episode(),
            "todo": lambda e: self.NotifyToServer(modConfig.AcceptQuestEvent, e),
            "done": lambda e: self.NotifyToServer(modConfig.SubmitQuestEvent, e),
            "shift": lambda e: self.NotifyToServer(modConfig.ShiftDialogueEvent, e)
        }

    def get_coroutine_mgr(self):
        return self.m_coroutine_mgr

    def Destroy(self):
        self.m_coroutine_mgr.destroy()
        self.un_listen_event()

    def listen_event(self):
        self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(),
                            modConfig.UiInitFinishedEvent, self, self.on_ui_init_finished)
        self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(),
                            modConfig.OnScriptTickClient, self, self.on_script_tick_client)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName, modConfig.DisplayDialogueEvent, self,
                            self.on_display_dialogue)
        self.ListenForEvent(modConfig.QuestModName, modConfig.QuestServerSystemName, modConfig.DisplayQuestEvent, self,
                            self.on_display_quest)

    def un_listen_event(self):
        self.UnListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(),
                              modConfig.UiInitFinishedEvent, self, self.on_ui_init_finished)
        self.UnListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(),
                              modConfig.OnScriptTickClient, self, self.on_script_tick_client)
        self.UnListenForEvent(modConfig.ModName, modConfig.ServerSystemName, modConfig.DisplayDialogueEvent, self,
                              self.on_display_dialogue)
        self.UnListenForEvent(modConfig.QuestModName, modConfig.QuestServerSystemName, modConfig.DisplayQuestEvent,
                              self, self.on_display_quest)

    def on_ui_init_finished(self, args):
        logger.info('==== %s ====' % '"init UI done": %s' % args)
        # 注册UI 详细解释参照《UI API》
        clientApi.RegisterUI(modConfig.ModName, modConfig.dialogueUIName, editorConfig.scriptFolderName + '.' + modConfig.dialogueUIClsPath,
                             modConfig.dialogueUIScreenDef)
        # 创建UI 详细解释参照《UI API》
        clientApi.CreateUI(modConfig.ModName, modConfig.dialogueUIName, {"isHud": 1})
        self.m_dialogue_ui_node = clientApi.GetUI(modConfig.ModName, modConfig.dialogueUIName)
        if self.m_dialogue_ui_node:
            self.m_dialogue_ui_node.initialize()
        else:
            logger.error('==== %s ====' % 'create UI: %s failed' % modConfig.dialogueUIScreenDef)
        # 这里取任务进度
        # TODO: 考虑延迟
        event_data = self.CreateEventData()
        event_data["id"] = self.m_player_id
        self.NotifyToServer(modConfig.GetQuestProgressesEvent, event_data)
        comp = self.CreateComponent(clientApi.GetLevelId(), modConfig.Minecraft, 'game')
        comp.ShowHealthBar(True)

    # 监听引擎ScriptTickClientEvent事件，引擎会执行该tick回调，1秒钟30帧
    def on_script_tick_client(self):
        self.m_coroutine_mgr.tick()

        if not self.m_pos_monitor:
            self.m_pos_monitor = True
            self.m_coroutine_mgr.start_coroutine(self.detect_pos())

    # 被引擎直接执行的父类的重写函数，引擎会执行该Update回调，1秒钟30帧
    def Update(self):
        pass

    def on_display_quest(self, data):
        progresses = data.get('progresses')
        if self.m_dialogue_ui_node:
            self.m_dialogue_ui_node.display_quest(progresses)
        positions = data.get('positions', {})
        self.m_attentive_positions = positions

    def on_display_dialogue(self, data):
        dialogue_id = data['dialogue_id']
        if dialogue_id is -1:
            return self.m_dialogue_ui_node.quit()
        dialogue_title = data.get('dialogue_title', '')
        self.m_dialogue_ui_node.display_dialogue(dialogue_id, dialogue_title)

    def chk(self, pos1, pos2, r, omit_altitude=False):
        abs1 = abs(pos1[0] - pos2[0])
        if abs1 > r:
            return False
        abs2 = abs(pos1[2] - pos2[2])
        if abs2 > r:
            return False
        if omit_altitude:
            return abs1 ** 2 + abs2 ** 2 <= r ** 2
        else:
            h = abs(pos1[1] - pos2[1])
            return h <= r and abs1 ** 2 + abs2 ** 2 + h ** 2 <= r ** 2

    def detect_pos(self):
        yield -16
        if self.m_attentive_positions:
            comp = self.CreateComponent(self.m_player_id, modConfig.Minecraft, modConfig.PosComponent)
            pos = comp.GetPos()
            if pos:
                matches = []
                for k, v in self.m_attentive_positions.copy().iteritems():
                    if self.chk(pos, v['spot'], v['radius']):
                        matches.append(k)
                event_data = self.CreateEventData()
                event_data["id"] = self.m_player_id
                event_data['matches'] = matches
                self.NotifyToServer(modConfig.ArriveEvent, event_data)
        self.m_pos_monitor = False

    def render(self, option):
        k, v = option
        event_data = self.CreateEventData()
        event_data["id"] = self.m_player_id
        event_data['phrase'] = v
        self.m_coroutine_mgr.delay_exec_func(self.m_dialogue_option_handlers[k], 0, event_data)
        # 选什么都关闭对话
        self.m_dialogue_ui_node._quit()
