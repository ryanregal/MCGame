# -*- coding: utf-8 -*-

import mod.server.extraServerApi as serverApi

# 用来打印规范格式的log
from .. import logger
from ..serverManager.coroutineMgrGas import CoroutineMgr
from ...modCommon import dialogueConfig as modConfig

ServerSystem = serverApi.GetServerSystemCls()


class DialogueServerSystem(ServerSystem):
    def __init__(self, namespace, system_name):
        ServerSystem.__init__(self, namespace, system_name)
        logger.info('==== %s ====' % 'init dialogueServerSystem')
        self.listen_event()

        self.m_coroutine_mgr = CoroutineMgr()
        self.m_quest_server_system_cache = None

    def get_coroutine_mgr(self):
        return self.m_coroutine_mgr

    def Destroy(self):
        self.m_quest_server_system_cache = None
        self.m_coroutine_mgr.destroy()
        self.un_listen_event()

    def listen_event(self):
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                            modConfig.OnScriptTickServer, self, self.on_script_tick_server)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                            modConfig.PlayerAttackEntityEvent, self, self.on_player_attack_entity)
        self.ListenForEvent(modConfig.ModName, modConfig.ClientSystemName, modConfig.ShiftDialogueEvent, self,
                            self.on_shift_dialogue)

    def un_listen_event(self):
        self.UnDefineEvent(modConfig.DisplayDialogueEvent)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                              modConfig.OnScriptTickServer, self, self.on_script_tick_server)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                              modConfig.PlayerAttackEntityEvent, self, self.on_player_attack_entity)
        self.UnListenForEvent(modConfig.ModName, modConfig.ClientSystemName, modConfig.ShiftDialogueEvent, self,
                              self.on_shift_dialogue)

    def trigger(self, player_id, npc_entity_id):
        """
        先找玩家进度的任务
        没有的话找该npc绑定的第一个符合的对话
        无论什么情况
        最多只能返回一个
        :param player_id: player entity id
        :param npc_entity_id: npc entity id
        :return: proper phrase or None
        """
        if not self.m_quest_server_system_cache:
            instance = serverApi.GetSystem(modConfig.QuestModName, modConfig.QuestServerSystemName)
            if instance:
                self.m_quest_server_system_cache = instance
        # TODO: 本身这么设计就有问题
        # TODO: 后续再补细节
        if self.m_quest_server_system_cache:
            for dialogue_id in modConfig.NPC_ENTITY_ID_DICT[npc_entity_id][modConfig.APPEAR_CONDITION_DONE]:
                quest_id = modConfig.DialogueConfig[dialogue_id]['postAppearDone']
                if self.m_quest_server_system_cache.can_submit(player_id, quest_id):
                    return dialogue_id
            for dialogue_id in modConfig.NPC_ENTITY_ID_DICT[npc_entity_id][modConfig.APPEAR_CONDITION_DOING]:
                quest_id = modConfig.DialogueConfig[dialogue_id]['postAppearDoing']
                if self.m_quest_server_system_cache.get_progress(player_id, quest_id):  # TODO: 是否要进行中且未完成
                    return dialogue_id
            for dialogue_id in modConfig.NPC_ENTITY_ID_DICT[npc_entity_id][modConfig.APPEAR_CONDITION_TODO]:
                quest_id = modConfig.DialogueConfig[dialogue_id]['postAppearTodo']
                data, can_accept = self.m_quest_server_system_cache.can_accept(player_id, quest_id)
                if data or can_accept:
                    return dialogue_id
        for dialogue_id in modConfig.NPC_ENTITY_ID_DICT[npc_entity_id][modConfig.APPEAR_CONDITION_NONE]:
            return dialogue_id

    def on_shift_dialogue(self, data):
        # player_id, phrase, name = data.get('id'), data.get('phrase'), data.get('dialogue_title')
        player_id, dialogue_id = data.get('id'), data.get('phrase')
        # if not player_id or not phrase:
        if not player_id or not dialogue_id:
            return
        dialogue = modConfig.DialogueConfig.get(dialogue_id)
        if not dialogue:
            logger.error('==== %s ====' % 'dialogue: %s 跳转对话不存在' % dialogue_id)
            return
        comp = self.CreateComponent(dialogue['npcEntityId'], modConfig.Minecraft, modConfig.NameComponent)
        self.push_dialogue(player_id, dialogue_id, (comp.GetName() or '') if comp else '')

    def on_player_attack_entity(self, args):
        victim_id, player_id = args.get('victimId'), args.get('playerId')
        if victim_id and player_id:
            if victim_id in modConfig.NPC_ENTITY_ID_DICT:
                # 的确是个npc
                args['cancel'] = True
                args['isKnockBack'] = False
                phrase = self.trigger(player_id, victim_id)  # 暂时都应该只有对话
                if phrase:
                    comp = self.CreateComponent(victim_id, modConfig.Minecraft, modConfig.NameComponent)
                    self.push_dialogue(player_id, phrase, (comp.GetName() or '') if comp else '')

    def on_script_tick_server(self):
        self.m_coroutine_mgr.tick()

    def push_dialogue(self, player_id, dialogue_id, name=''):
        event_data = self.CreateEventData()
        event_data['dialogue_id'] = dialogue_id
        if name:
            event_data['dialogue_title'] = name
        self.NotifyToClient(player_id, modConfig.DisplayDialogueEvent, event_data)
