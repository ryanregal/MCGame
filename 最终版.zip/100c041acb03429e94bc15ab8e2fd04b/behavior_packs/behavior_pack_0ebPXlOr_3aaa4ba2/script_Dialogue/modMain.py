# -*- coding: utf-8 -*-

import mod.client.extraClientApi as clientApi
import editorConfig
import mod.server.extraServerApi as serverApi
from mod.common.mod import Mod
from modCommon import dialogueConfig as modConfig

from . import logger


@Mod.Binding(name=modConfig.ModName, version=modConfig.ModVersion)
class DialogueMod(object):
    def __init__(self):
        logger.info("===== init DialogueMod =====")

    @Mod.InitServer()
    def DialogueServerInit(self):
        logger.info("===== init DialogueServer =====")
        serverApi.RegisterSystem(modConfig.ModName, modConfig.ServerSystemName, editorConfig.scriptFolderName + '.' + modConfig.ServerSystemClsPath)

    @Mod.DestroyServer()
    def DialogueServerDestroy(self):
        logger.info("===== destroy DialogueServer =====")

    @Mod.InitClient()
    def DialogueClientInit(self):
        logger.info("===== init DialogueClient =====")
        clientApi.RegisterSystem(modConfig.ModName, modConfig.ClientSystemName, editorConfig.scriptFolderName + '.' + modConfig.ClientSystemClsPath)

    @Mod.DestroyClient()
    def DialogueClientDestroy(self):
        logger.info("===== destroy DialogueClient =====")
