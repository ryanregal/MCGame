compId = "World"
dataDict = {
	"624dec4e-6a81-411c-92f3-de29ba10c35e": {
		"cheat": True,
		"cheatInfo": {
			"command_blocks_enabled": True,
			"daylight_cycle": False,
			"entities_drop_loot": True,
			"keep_inventory": False,
			"mob_griefing": True,
			"mob_spawn": False,
			"random_tick_speed": 1,
			"stable_time": 6000,
			"weather_cycle": False
		},
		"difficulty": 1,
		"gameMode": 0,
		"isCreate": False,
		"levelId": "",
		"optionInfo": {
			"experimental_gameplay": False,
			"fire_spreads": True,
			"mob_loot": True,
			"natural_regeneration": True,
			"pvp": True,
			"show_coordinates": True,
			"tile_drops": True,
			"tnt_explodes": True
		},
		"spawn": [
			0,
			0,
			0
		],
		"storyline": "",
		"title": "123",
		"uuid": "624dec4e-6a81-411c-92f3-de29ba10c35e"
	}
}
isUnique = True
scriptFolderName = "script_World"
