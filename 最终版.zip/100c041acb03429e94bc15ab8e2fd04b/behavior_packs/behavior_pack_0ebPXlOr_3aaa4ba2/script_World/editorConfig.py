# -*- coding: utf-8 -*-
isUnique = True
LastVersion = [
	0,
	0,
	2
]
compId = 'World'
version = [
	0,
	0,
	2
]
dataDict = {
	'06c25804-10cb-42e7-bb30-790de81418a2': {
		'cheat': True,
		'cheatInfo': {
			'command_blocks_enabled': False,
			'daylight_cycle': False,
			'entities_drop_loot': True,
			'keep_inventory': False,
			'mob_griefing': False,
			'mob_spawn': False,
			'random_tick_speed': 1,
			'stable_time': 12000,
			'weather_cycle': False
		},
		'difficulty': 1,
		'gameMode': 0,
		'isCreate': False,
		'levelId': '',
		'optionInfo': {
			'experimental_gameplay': False,
			'fire_spreads': True,
			'mob_loot': True,
			'natural_regeneration': True,
			'pvp': True,
			'show_coordinates': True,
			'tile_drops': True,
			'tnt_explodes': True
		},
		'spawn': [
			0,
			0,
			0
		],
		'storyline': '',
		'title': 'TaskTemplate2',
		'uuid': '06c25804-10cb-42e7-bb30-790de81418a2'
	}
}
scriptFolderName = 'script_World'
