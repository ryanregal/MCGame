# -*- coding: utf-8 -*-
# 这个文件保存了MOD中使用的一些变量，这样做的好处很多，建议参考

# Mod Version
ModName = "QuestMod"
ModVersion = "0.0.1"

# Server System
ServerSystemName = "questServerSystem"
ServerSystemClsPath = "neteaseQuestScript.modServer.serverSystem.questServerSystem.QuestServerSystem"

# Dialogue
DialogueModName = "DialogueMod"
DialogueClientSystemName = "dialogueClientSystem"

# Engine
Minecraft = "Minecraft"

# Server Component
# Engine
EngineTypeComponent = "engineType"
ScriptTypeCompServer = "type"
PosComponent = "pos"
RotComponent = "rot"
ItemComponent = 'item'
NameComponent = 'name'
ExtraDataComponent = 'extraData'
CommandComponent = 'command'

# Server Event
# Engine
LoadServerAddonScriptsAfter = 'LoadServerAddonScriptsAfter'
ServerChatEvent = "ServerChatEvent"
OnScriptTickServer = "OnScriptTickServer"
AddServerPlayerEvent = "AddServerPlayerEvent"
MobDieEvent = 'MobDieEvent'
AddLevelEvent = 'AddLevelEvent'
# Custom
DisplayDialogueEvent = 'DisplayDialogueEvent'
DisplayQuestEvent = 'DisplayQuestEvent'
HustleEvent = 'HustleEvent'
RefreshEvent = 'RefreshEvent'

# Client Event
# Engine
UiInitFinishedEvent = "UiInitFinished"
OnScriptTickClient = "OnScriptTickClient"
# Custom
AcceptQuestEvent = 'AcceptQuestEvent'
SubmitQuestEvent = 'SubmitQuestEvent'
ShiftDialogueEvent = 'ShiftDialogueEvent'
GetQuestProgressesEvent = 'GetQuestProgressesEvent'
ArriveEvent = 'ArriveEvent'

# UI
dialogueUIName = "dialogueUI"
dialogueUIClsPath = "neteaseQuestScript.modClient.ui.dialogueClientUI.DialogueScreen"
dialogueUIScreenDef = "dialogueUI.main"

QUEST_KILL_MONSTER = 1
QUEST_COLLECT_ITEM = 2
QUEST_ARRIVE_PLACE = 3
QUEST_PLAYER_LEVEL = 4

# editor config begin
QuestConfig = {'合成金剑': {'uuid': '433206c6-6a14-450c-a530-7621ab78ec6a', 'questName': '合成金剑', 'preconditions': {'lv': 0, 'stuff': [{'cost': False, 'n': 0, 'type': ('minecraft:golden_sword', 0)}], 'preQuest': ''}, 'questType': 2, 'questMobType': 'minecraft:chicken', 'questItemType': ('minecraft:golden_sword', 0), 'cost': True, 'amount': 1, 'spot': (6886.0, 67.0, -15.0), 'radius': 10, 'desc': '快去找找原料吧！', 'goal': 1, 'limit': 1, 'npcEntityId': '-85899345755', 'rewards': {'exp': 100, 'drugs': [{'n': 1, 'type': ('minecraft:golden_sword', 0)}]}}, '找到女巫家': {'uuid': '5bd5b305-0f1e-4677-a3e6-6d1257d2079e', 'questName': '找到女巫家', 'preconditions': {'lv': 0, 'stuff': [], 'preQuest': '收集元素'}, 'questType': 3, 'questMobType': 'minecraft:chicken', 'questItemType': ('minecraft:apple', 0), 'cost': False, 'amount': 1, 'spot': (6982.0, 65.0, 97.0), 'radius': 8, 'desc': '根据魔鬼的提示，找到女巫家的入口', 'goal': 1, 'limit': 1, 'npcEntityId': '', 'rewards': {'exp': 0, 'drugs': [{'n': 1, 'type': ('minecraft:seaLantern', 0)}]}}, '合成岩浆膏': {'uuid': '690f5468-7bf1-4826-aeeb-cfd4ceed63c6', 'questName': '合成岩浆膏', 'preconditions': {'lv': 0, 'stuff': [], 'preQuest': '合成海洋之心'}, 'questType': 2, 'questMobType': 'minecraft:chicken', 'questItemType': ('minecraft:magma_cream', 0), 'cost': True, 'amount': 1, 'spot': None, 'radius': 0, 'desc': '耐心在屋内找找，会有意想不到的惊喜！', 'goal': 1, 'limit': 1, 'npcEntityId': '-85899345755', 'rewards': {'exp': 500, 'drugs': [{'n': 1, 'type': ('minecraft:magma_cream', 0)}]}}, '收集元素': {'uuid': '6de7b6b1-b984-46c5-add4-3696f502e52c', 'questName': '收集元素', 'preconditions': {'lv': 0, 'stuff': [], 'preQuest': ''}, 'questType': 2, 'questMobType': 'ntestaskdemo:mon_pigman', 'questItemType': ('minecraft:enchanted_book', 0), 'cost': True, 'amount': 1, 'spot': 'None', 'radius': 0, 'desc': '合成元素之书%p，找到§a魔鬼', 'goal': 1, 'limit': 1, 'npcEntityId': '-188978561022', 'rewards': {'exp': 500, 'drugs': [{'n': 1, 'type': ('minecraft:diamond_sword', 0)}]}}, '合成海洋之心': {'uuid': '9dd2f44f-137f-47f0-b0ba-3383ba227a02', 'questName': '合成海洋之心', 'preconditions': {'lv': 0, 'stuff': [], 'preQuest': '合成金剑'}, 'questType': 2, 'questMobType': 'minecraft:chicken', 'questItemType': ('minecraft:heart_of_the_sea', 0), 'cost': False, 'amount': 1, 'spot': None, 'radius': 0, 'desc': '听说在运动室可以提取出青金石噢！', 'goal': 1, 'limit': 1, 'npcEntityId': '-85899345755', 'rewards': {'exp': 300, 'drugs': [{'n': 1, 'type': ('minecraft:heart_of_the_sea', 0)}]}}}
# editor config end
