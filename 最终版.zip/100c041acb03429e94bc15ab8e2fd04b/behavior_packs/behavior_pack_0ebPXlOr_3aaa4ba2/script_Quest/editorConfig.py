# -*- coding: utf-8 -*-
isUnique = False
compId = 'Quest'
LastVersion = [
	0,
	3,
	0
]
version = [
	0,
	3,
	0
]
dataDict = {
	'433206c6-6a14-450c-a530-7621ab78ec6a': {
		'amount': 1,
		'cost': True,
		'desc': '快去找找原料吧！',
		'goal': 1,
		'limit': 1,
		'npcEntityId': '-85899345755',
		'preconditions': {
			'lv': 0,
			'preQuest': '',
			'stuff': [
				{
					'cost': False,
					'n': 0,
					'type': (
						'minecraft:golden_sword',
						0
					)
				}
			]
		},
		'questItemType': (
			'minecraft:golden_sword',
			0
		),
		'questMobType': 'minecraft:chicken',
		'questName': '合成金剑',
		'questType': 2,
		'radius': 10,
		'rewards': {
			'drugs': [
				{
					'n': 1,
					'type': (
						'minecraft:golden_sword',
						0
					)
				}
			],
			'exp': 100
		},
		'spot': (
			6886.0,
			67.0,
			-15.0
		),
		'uuid': '433206c6-6a14-450c-a530-7621ab78ec6a'
	},
	'5bd5b305-0f1e-4677-a3e6-6d1257d2079e': {
		'amount': 1,
		'cost': False,
		'desc': '根据魔鬼的提示，找到女巫家的入口',
		'goal': 1,
		'limit': 1,
		'npcEntityId': '',
		'preconditions': {
			'lv': 0,
			'preQuest': '收集元素',
			'stuff': []
		},
		'questItemType': (
			'minecraft:apple',
			0
		),
		'questMobType': 'minecraft:chicken',
		'questName': '找到女巫家',
		'questType': 3,
		'radius': 8,
		'rewards': {
			'drugs': [
				{
					'n': 1,
					'type': (
						'minecraft:seaLantern',
						0
					)
				}
			],
			'exp': 0
		},
		'spot': (
			6982.0,
			65.0,
			97.0
		),
		'uuid': '5bd5b305-0f1e-4677-a3e6-6d1257d2079e'
	},
	'690f5468-7bf1-4826-aeeb-cfd4ceed63c6': {
		'amount': 1,
		'cost': True,
		'desc': '耐心在屋内找找，会有意想不到的惊喜！',
		'goal': 1,
		'limit': 1,
		'npcEntityId': '-85899345755',
		'preconditions': {
			'lv': 0,
			'preQuest': '合成海洋之心',
			'stuff': []
		},
		'questItemType': (
			'minecraft:magma_cream',
			0
		),
		'questMobType': 'minecraft:chicken',
		'questName': '合成岩浆膏',
		'questType': 2,
		'radius': 0,
		'rewards': {
			'drugs': [
				{
					'n': 1,
					'type': (
						'minecraft:magma_cream',
						0
					)
				}
			],
			'exp': 500
		},
		'spot': None,
		'uuid': '690f5468-7bf1-4826-aeeb-cfd4ceed63c6'
	},
	'6de7b6b1-b984-46c5-add4-3696f502e52c': {
		'amount': 1,
		'cost': True,
		'desc': '合成元素之书%p，找到§a魔鬼',
		'goal': 1,
		'limit': 1,
		'npcEntityId': '-188978561022',
		'preconditions': {
			'lv': 0,
			'preQuest': '',
			'stuff': []
		},
		'questItemType': (
			'minecraft:enchanted_book',
			0
		),
		'questMobType': 'ntestaskdemo:mon_pigman',
		'questName': '收集元素',
		'questType': 2,
		'radius': 0,
		'rewards': {
			'drugs': [
				{
					'n': 1,
					'type': (
						'minecraft:diamond_sword',
						0
					)
				}
			],
			'exp': 500
		},
		'spot': 'None',
		'uuid': '6de7b6b1-b984-46c5-add4-3696f502e52c'
	},
	'9dd2f44f-137f-47f0-b0ba-3383ba227a02': {
		'amount': 1,
		'cost': False,
		'desc': '听说在运动室可以提取出青金石噢！',
		'goal': 1,
		'limit': 1,
		'npcEntityId': '-85899345755',
		'preconditions': {
			'lv': 0,
			'preQuest': '合成金剑',
			'stuff': []
		},
		'questItemType': (
			'minecraft:heart_of_the_sea',
			0
		),
		'questMobType': 'minecraft:chicken',
		'questName': '合成海洋之心',
		'questType': 2,
		'radius': 0,
		'rewards': {
			'drugs': [
				{
					'n': 1,
					'type': (
						'minecraft:heart_of_the_sea',
						0
					)
				}
			],
			'exp': 300
		},
		'spot': None,
		'uuid': '9dd2f44f-137f-47f0-b0ba-3383ba227a02'
	}
}
scriptFolderName = 'script_Quest'
