# -*- coding: utf-8 -*-

import time
from collections import Counter

# 获取引擎模块game
import mod.server.extraServerApi as serverApi

# 用来打印规范格式的log
from .. import logger
from ..serverManager.coroutineMgrGas import CoroutineMgr
from ...modCommon import questConfig as modConfig

ServerSystem = serverApi.GetServerSystemCls()


class QuestServerSystem(ServerSystem):
    ITEM_TYPE = serverApi.GetMinecraftEnum().ItemType
    ENTITY_TYPE = serverApi.GetMinecraftEnum().EntityType

    def __init__(self, namespace, system_name):
        ServerSystem.__init__(self, namespace, system_name)
        logger.info('==== %s ====' % 'init QuestServerSystem')
        self.listen_event()

        self.m_doing_records = {}
        self.m_done_records = {}
        self.m_player_level_dict = {}

        self.m_player_attentive_items = {}
        self.m_player_attentive_holding_dict = {}
        self.m_player_item_monitor = False

        self.m_coroutine_mgr = CoroutineMgr()

    def get_coroutine_mgr(self):
        return self.m_coroutine_mgr

    def Destroy(self):
        comp = self.CreateComponent(serverApi.GetLevelId(), modConfig.Minecraft, modConfig.ExtraDataComponent)
        comp.SetExtraData("doing_records", self.m_doing_records)
        comp.SetExtraData("done_records", self.m_done_records)
        comp.SetExtraData("player_level_dict", self.m_player_level_dict)
        self.un_listen_event()

    def listen_event(self):
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                            modConfig.LoadServerAddonScriptsAfter, self, self.on_load_server_addon_scripts_after)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                            modConfig.OnScriptTickServer, self, self.on_script_tick_server)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), modConfig.MobDieEvent,
                            self, self.on_mob_die)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), modConfig.AddLevelEvent,
                            self, self.on_add_level)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                            modConfig.AddServerPlayerEvent, self, self.on_add_server_player)
        self.ListenForEvent(modConfig.DialogueModName, modConfig.DialogueClientSystemName, modConfig.AcceptQuestEvent,
                            self, self.on_accept_quest)
        self.ListenForEvent(modConfig.DialogueModName, modConfig.DialogueClientSystemName, modConfig.SubmitQuestEvent,
                            self, self.on_submit_quest)
        self.ListenForEvent(modConfig.DialogueModName, modConfig.DialogueClientSystemName,
                            modConfig.GetQuestProgressesEvent, self, self.on_get_quest_progresses)
        self.ListenForEvent(modConfig.DialogueModName, modConfig.DialogueClientSystemName, modConfig.ArriveEvent, self,
                            self.on_arrive)
        self.ListenForEvent(modConfig.ModName, modConfig.ServerSystemName, modConfig.HustleEvent, self, self.on_hustle)

    def un_listen_event(self):
        self.UnDefineEvent(modConfig.DisplayQuestEvent)
        self.UnDefineEvent(modConfig.HustleEvent)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                              modConfig.LoadServerAddonScriptsAfter, self, self.on_load_server_addon_scripts_after)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                              modConfig.OnScriptTickServer, self, self.on_script_tick_server)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), modConfig.MobDieEvent,
                              self, self.on_mob_die)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), modConfig.AddLevelEvent,
                              self, self.on_add_level)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                              modConfig.AddServerPlayerEvent, self, self.on_add_server_player)
        self.UnListenForEvent(modConfig.DialogueModName, modConfig.DialogueClientSystemName, modConfig.AcceptQuestEvent,
                              self, self.on_accept_quest)
        self.UnListenForEvent(modConfig.DialogueModName, modConfig.DialogueClientSystemName, modConfig.SubmitQuestEvent,
                              self, self.on_submit_quest)
        self.UnListenForEvent(modConfig.DialogueModName, modConfig.DialogueClientSystemName,
                              modConfig.GetQuestProgressesEvent, self, self.on_get_quest_progresses)
        self.UnListenForEvent(modConfig.DialogueModName, modConfig.DialogueClientSystemName, modConfig.ArriveEvent,
                              self, self.on_arrive)
        self.UnListenForEvent(modConfig.ModName, modConfig.ServerSystemName, modConfig.HustleEvent, self,
                              self.on_hustle)

    def on_hustle(self, data):
        player_id, item_id = data.get('id'), data.get('item_id')
        self.update_quest(player_id, modConfig.QUEST_COLLECT_ITEM, item_id)

    def on_arrive(self, data):
        player_id, matches = data.get('id'), data.get('matches')
        if player_id and matches:
            for quest_id in matches:
                self.update_quest(player_id, modConfig.QUEST_ARRIVE_PLACE, quest_id, 1)

    def on_get_quest_progresses(self, data):
        player_id = data.get('id')
        if player_id:
            self.push_quest(player_id)

    def on_accept_quest(self, data):
        """
        接任务
        """
        player_id, quest_id = data.get('id'), data.get('phrase')
        if not player_id or not quest_id:
            return
        self.accept_quest(player_id, quest_id)

    def on_submit_quest(self, data):
        """
        交任务
        """
        player_id, quest_id = data.get('id'), data.get('phrase')
        if not player_id or not quest_id:
            return
        self.submit_quest(player_id, quest_id)

    def on_add_server_player(self, args):
        player_id = args.get('id')
        self.m_coroutine_mgr.delay_exec_func(self.push_quest, 4, player_id)

    def on_add_level(self, args):
        player_id, new_level = args.get('id'), args.get('newLevel')
        self.m_player_level_dict[player_id] = new_level
        self.update_quest(player_id, modConfig.QUEST_PLAYER_LEVEL, 'player_level', new_level)

    def on_mob_die(self, args):
        victim_id, attacker_id = args.get('id'), args.get('attacker')
        # 暂时先一个一个更新
        self.update_quest(attacker_id, modConfig.QUEST_KILL_MONSTER,
                          self.CreateComponent(victim_id, modConfig.Minecraft,
                                               modConfig.EngineTypeComponent).GetEngineTypeStr(), 1)

    def on_load_server_addon_scripts_after(self, *args):
        logger.info('==== %s ====' % 'restore dialogueServerSystem')
        comp = self.CreateComponent(serverApi.GetLevelId(), modConfig.Minecraft, modConfig.ExtraDataComponent)
        doing_records = comp.GetExtraData("doing_records")
        done_records = comp.GetExtraData("done_records")
        player_level_dict = comp.GetExtraData("player_level_dict")
        if doing_records:
            self.m_doing_records = doing_records
        else:
            logger.warning('==== %s ====' % 'restore dialogueServerSystem missing doing_records')
        if done_records:
            self.m_done_records = done_records
        else:
            logger.warning('==== %s ====' % 'restore dialogueServerSystem missing done_records')
        if player_level_dict:
            self.m_player_level_dict = player_level_dict
        else:
            logger.warning('==== %s ====' % 'restore dialogueServerSystem missing player_level_dict')

    def on_script_tick_server(self):
        self.m_coroutine_mgr.tick()

        if not self.m_player_item_monitor:
            self.m_player_item_monitor = True
            self.m_coroutine_mgr.start_coroutine(self.detect_player_item())

    def detect_player_item(self):
        yield -44
        for player_id, attentive_items in self.m_player_attentive_items.iteritems():
            holding_dict = {item_id: 0 for item_id in attentive_items}
            comp = self.CreateComponent(player_id, modConfig.Minecraft, modConfig.ItemComponent)
            inv = serverApi.GetMinecraftEnum().ItemPosType.INVENTORY
            for i in range(36):
                try:
                    slot_data = comp.GetPlayerItem(inv, i) or {}
                    item_id = '{}:{}'.format(slot_data.get('itemName'), slot_data.get('auxValue'))
                    if item_id and item_id in attentive_items:
                        count = slot_data.get('count')
                        if count:
                            # holding_dict[item_id] = holding_dict.setdefault(item_id, 0) + count
                            holding_dict[item_id] += count
                except:
                    continue
            for item_id, n in holding_dict.iteritems():
                if n != self.m_player_attentive_holding_dict.setdefault(player_id, {}).setdefault(item_id, 0):
                    self.m_player_attentive_holding_dict[player_id][item_id] = n
                    event_data = self.CreateEventData()
                    event_data["id"] = player_id
                    event_data['item_id'] = item_id
                    self.BroadcastEvent(modConfig.HustleEvent, event_data)
        self.m_player_item_monitor = False

    def update_quest(self, entity_id, kind, k, v=0):
        flag = False
        autos = []
        for quest_id, progress in self.m_doing_records.get(entity_id, {}).get(kind, {}).iteritems():
            quest = modConfig.QuestConfig.get(quest_id)
            if not quest:
                logger.error('==== %s ====' % '"update quest 不存在": %s' % quest_id)
                continue
            if kind == modConfig.QUEST_KILL_MONSTER:
                # entity_type = getattr(self.ENTITY_TYPE, quest['questMobType'].capitalize(), False)
                # if not entity_type:
                #     logger.error('==== 这任务更新不了因为怪物类型为空 %s ====', quest)
                # if k == entity_type:
                if k == quest['questMobType']:
                    progress[0] += v
                    flag = True  # 改了就要通知
            elif kind == modConfig.QUEST_COLLECT_ITEM:
                item_id = reduce(lambda x, y: '{}:{}'.format(x, y), quest['questItemType'])
                if not item_id:
                    logger.error('==== 这任务更新不了因为道具id为空 %s ====', quest)
                if k == item_id:
                    cur = self.get_default(entity_id, quest)[0]
                    if progress[0] != cur:
                        progress[0] = cur
                        flag = True  # 改了就要通知
            elif kind == modConfig.QUEST_ARRIVE_PLACE:
                if k == quest_id:
                    if not progress[0]:
                        progress[0] += v
                    flag = True  # 改了就要通知
            elif kind == modConfig.QUEST_PLAYER_LEVEL:
                cur = self.get_default(entity_id, quest)[0]
                if progress[0] != cur:
                    progress[0] = cur
                    flag = True  # 改了就要通知
            if self._can_submit(quest_id, progress) and not quest.get('npcEntityId'):
                autos.append(quest_id)
        for quest_id in autos:
            self.submit_quest(entity_id, quest_id)
        if flag:
            self.m_coroutine_mgr.delay_exec_func(self.push_quest, 2, entity_id)

    def accept_quest(self, player_id, quest_id, name=''):
        quest = modConfig.QuestConfig.get(quest_id)
        if not quest:
            logger.error('==== %s ====' % '"accept quest 不存在": %s' % quest_id)
            return
        quest_data = self.m_doing_records.setdefault(player_id, {})
        holding_dict, can_accept = self.can_accept(player_id, quest_id, True)
        if holding_dict or can_accept:
            kind = quest['questType']
            preconditions = quest.get('preconditions', {})
            # if preconditions.get('cost'):
            stuff = preconditions.get('stuff')
            if stuff:
                # 此时holding_dict是位置
                stuff_dict = Counter()
                for item in stuff:
                    item_id = reduce(lambda x, y: '{}:{}'.format(x, y), item['type'])
                    if not item_id:
                        logger.error('==== 走到这里居然还有道具id为空 %s ====', item)
                    if item['cost']:
                        stuff_dict.update({item_id: item['n']})
                if stuff_dict:
                    if not self.cost_stuff(player_id, stuff_dict, holding_dict):
                        # 没扣成功
                        logger.error('==== %s ====' % '"accept quest 扣材料失败": (%s, %s, %s, %s)' % (
                            player_id, quest_id, stuff, holding_dict))
                    else:
                        if isinstance(holding_dict, dict):
                            for item_id in holding_dict.keys():
                                self.m_coroutine_mgr.delay_exec_func(
                                    self.update_quest, 0, player_id, modConfig.QUEST_COLLECT_ITEM, item_id)
            quest_data.setdefault(kind, {})[quest_id] = self.get_default(player_id, quest)
            self.push_quest(player_id)
            # self.notify(player_id, '成功接受任务')
            self.notify(player_id, '系统：成功接受任务`{}`'.format(quest['questName']))
            # accept_proceeds = quest.get('accept_proceeds')
            # if not accept_proceeds:
            #     return self.push_dialogue(player_id, -1)
            # for phrase in accept_proceeds:
            #     self.on_accept_quest({'id': player_id, 'phrase': phrase, 'dialogue_title': name})
            pass
        else:
            # self.notify(player_id, '接受任务失败')
            self.notify(player_id, '§c系统：接受任务`{}`失败'.format(quest['questName']))

    def submit_quest(self, player_id, quest_id, name=''):
        quest = modConfig.QuestConfig.get(quest_id)
        if not quest:
            logger.error('==== %s ====' % '"submit quest 不存在": %s' % quest_id)
            return
        quest_data = self.m_doing_records.setdefault(player_id, {})
        kind = quest.get('questType')
        if not kind:
            logger.error('==== %s ====' % '"submit quest 不能没类型": %s' % quest_id)
            return
        if quest_id not in quest_data.get(kind, {}):
            logger.warning('==== %s ====' % '"submit quest 未接取": %s' % quest_id)
            return
        if self._can_submit(quest_id, quest_data[kind][quest_id]):
            if quest.get('cost') and kind == modConfig.QUEST_COLLECT_ITEM:
                stuff = {reduce(lambda x, y: '{}:{}'.format(x, y), quest['questItemType']): quest['amount']}
                if stuff:
                    holding_dict = self.can_cost_stuff(player_id, stuff)
                    if not holding_dict:
                        logger.error('==== %s ====' % '"submit quest 完成了却无法扣材料": %s' % quest_id)
                        return
                    elif not self.cost_stuff(player_id, stuff, holding_dict):
                        # 没扣成功
                        logger.error('==== %s ====' % '"submit quest 完成了却扣材料失败": (%s, %s, %s, %s)' % (
                            player_id, quest_id, stuff, holding_dict))
                    else:
                        for item_id in holding_dict.keys():
                            self.m_coroutine_mgr.delay_exec_func(
                                self.update_quest, 0, player_id, modConfig.QUEST_COLLECT_ITEM, item_id)
            del quest_data[kind][quest_id]
            if player_id not in self.m_done_records:
                self.m_done_records[player_id] = {}
            if quest_id not in self.m_done_records[player_id]:
                self.m_done_records[player_id][quest_id] = 0
            self.m_done_records[player_id][quest_id] += 1
            rewards = quest.get('rewards')
            if rewards:
                if rewards.get('exp'):
                    # 处理加经验
                    comp = self.CreateComponent(player_id, modConfig.Minecraft, modConfig.CommandComponent)
                    comp.SetCommand('/xp {} @s'.format(rewards['exp']), player_id)
                drugs = rewards.get('drugs')
                if drugs:
                    comp = self.CreateComponent(player_id, modConfig.Minecraft, modConfig.ItemComponent)
                    demand = len(drugs)
                    free = []
                    if len(free) < demand:
                        inv = serverApi.GetMinecraftEnum().ItemPosType.INVENTORY
                        for i in range(36):
                            if comp.GetPlayerItem(inv, i) is None:
                                free.append(i)
                                if len(free) >= demand:
                                    break
                    for item in drugs:
                        if item['n'] > 0:
                            item_dict = {
                                'itemName': item['type'][0],
                                'count': item['n'],
                                'enchantData': [],
                                'auxValue': item['type'][1],
                                'extraId': ''
                            }
                            if free:
                                comp.SpawnItemToPlayerInv(item_dict, player_id, free.pop(0))
                            else:
                                self.notify(player_id, '§c系统：背包已满掉落在地')
                                comp.SpawnItemToLevel(item_dict, self.CreateComponent(player_id, modConfig.Minecraft, "dimension").GetPlayerDimensionId(), self.CreateComponent(player_id, modConfig.Minecraft, modConfig.PosComponent).GetPos())
            self.push_quest(player_id)
            # self.notify(player_id, '成功完成任务')
            self.notify(player_id, '系统：完成任务`{}`'.format(quest['questName']))
            if rewards:
                self.notify(player_id, '系统：获得任务奖励——{}{}'.format('经验*{}'.format(rewards['exp']) if rewards.get('exp') else '', '{}物品*{}'.format(rewards.get('exp') and '、' or '', len(rewards['drugs'])) if rewards.get('drugs') else ''))
            # commit_proceeds = quest.get('commit_proceeds')
            # if not commit_proceeds:
            #     return self.push_dialogue(player_id, -1)
            # for phrase in commit_proceeds:
            #     self.on_accept_quest({'id': player_id, 'phrase': phrase, 'dialogue_title': name})
            pass
        else:
            logger.warning('==== %s ====' % '"submit quest 未完成": %s' % quest_data[kind][quest_id])
            # self.notify(player_id, '完成任务失败')
            self.notify(player_id, '§c系统：完成任务`{}`失败'.format(quest['questName']))

    def get_default(self, player_id, quest):
        default = [0, time.time()]
        kind = quest['questType']
        if kind == modConfig.QUEST_COLLECT_ITEM:
            item_id = reduce(lambda x, y: '{}:{}'.format(x, y), quest['questItemType'])
            if not item_id:
                logger.error('==== 这任务完不成了因为道具id为空 %s ====', quest)
            else:
                comp = self.CreateComponent(player_id, modConfig.Minecraft, modConfig.ItemComponent)
                inv = serverApi.GetMinecraftEnum().ItemPosType.INVENTORY
                for i in range(36):
                    try:
                        slot_data = comp.GetPlayerItem(inv, i) or {}
                        if '{}:{}'.format(slot_data.get('itemName'), slot_data.get('auxValue')) == item_id:
                            count = slot_data.get('count')
                            if count:
                                default[0] += count
                    except:
                        continue
        elif kind == modConfig.QUEST_PLAYER_LEVEL:
            default[0] = self.m_player_level_dict.get(player_id, 0)
        return default

    def can_cost_stuff(self, player_id, stuff):
        """
        如果够材料返回材料位置
        不够反空
        :param player_id:
        :param stuff: 不能是空
        :type stuff: dict
        :return:
        """
        comp = self.CreateComponent(player_id, modConfig.Minecraft, modConfig.ItemComponent)
        inv = serverApi.GetMinecraftEnum().ItemPosType.INVENTORY
        holding_dict = {}
        for item_id, n in stuff.iteritems():
            # 暂时先这样因为dict不能重key所以不会多算
            holding_dict[item_id] = []
            if n > 0:
                for i in range(36):
                    try:
                        slot_data = comp.GetPlayerItem(inv, i) or {}
                        if '{}:{}'.format(slot_data.get('itemName'), slot_data.get('auxValue')) == item_id:
                            count = slot_data.get('count')
                            if count:
                                holding_dict[item_id].append((count, i))
                                if reduce(lambda x, y: (x[0] + y[0], 0), holding_dict[item_id])[0] >= n:
                                    break
                    except:
                        continue
                if not holding_dict[item_id] or reduce(lambda x, y: (x[0] + y[0], 0), holding_dict[item_id])[0] < n:
                    # logger.warning('==== %s ====' % '"%s 材料不足": %s' % (quest_id, item_id))
                    return
        return holding_dict

    def cost_stuff(self, player_id, stuff, holding_dict):
        """
        理论上都是查出来够才扣
        """
        try:
            costing_stuff = dict(stuff)
            comp = self.CreateComponent(player_id, modConfig.Minecraft, modConfig.ItemComponent)
            for item_id, distributions in holding_dict.iteritems():
                for count, slot_pos in distributions:
                    n = min(costing_stuff[item_id], count)
                    if not comp.SetInvItemNum(slot_pos, count - n):
                        logger.error('==== cost stuff 扣材料失败 位置 %s 有 %s 个扣 %s 个 ====', slot_pos, count, n)
                        return
                    costing_stuff[item_id] -= n
                    if costing_stuff[item_id] <= 0:
                        break
            return True
        except:
            pass

    def can_accept(self, player_id, quest_id, alert=False):
        holding_dict = {}
        quest = modConfig.QuestConfig.get(quest_id)
        if not quest:
            logger.error('==== %s ====' % '"can accept quest 不存在": %s' % quest_id)
            return holding_dict, False
        quest_data = self.m_doing_records.setdefault(player_id, {})
        kind = quest.get('questType')
        if not kind:
            logger.error('==== %s ====' % '"can accept quest 不能没类型": %s' % quest_id)
            return holding_dict, False
        if quest_id in quest_data.get(kind, {}):
            logger.warning('==== %s ====' % '"can accept quest 已存在": %s' % quest_data[kind][quest_id])
            return holding_dict, False
        limit = quest['limit']
        # if limit and self.m_done_records.get(player_id, {}).get(quest_id, 0) >= limit:
        if 0 <= limit <= self.m_done_records.get(player_id, {}).get(quest_id, 0):
            logger.warning('==== %s ====' % '"can accept quest 完成达上限": %s' % quest_id)
            if alert:
                self.notify(player_id, '§c`{}`：完成次数已达上限'.format(quest['questName']))
            return holding_dict, False
        preconditions = quest.get('preconditions', {})
        if preconditions:
            lv = preconditions.get('lv', 0)
            stuff = preconditions.get('stuff', [])
            pre_quest_id = preconditions.get('preQuest')
            if self.m_player_level_dict.get(player_id, 0) < lv:
                logger.warning('==== %s ====' % '"can accept quest 等级不足": %s' % quest_id)
                if alert:
                    self.notify(player_id, '§c`{}`：等级不足'.format(quest['questName']))
                return holding_dict, False
            if stuff:
                stuff_dict = Counter()
                for item in stuff:
                    item_id = reduce(lambda x, y: '{}:{}'.format(x, y), item['type'])
                    if not item_id:
                        logger.warning('==== 道具id为空 %s ====', item)
                    stuff_dict.update({item_id: item['n']})
                holding_dict = self.can_cost_stuff(player_id, stuff_dict)
                if not holding_dict:
                    logger.warning('==== %s ====' % '"can accept quest 材料不足": %s' % quest_id)
                    if alert:
                        self.notify(player_id, '§c`{}`：材料不足'.format(quest['questName']))
                    return holding_dict, False
            if pre_quest_id:
                if pre_quest_id not in self.m_done_records.get(player_id, {}):
                    logger.warning('==== %s ====' % '"can accept quest 前置任务未完成": %s' % quest_id)
                    if alert:
                        self.notify(player_id, '§c`{}`：未完成前置任务'.format(quest['questName']))
                    return holding_dict, False
        return holding_dict, True

    def _can_submit(self, quest_id, progress):
        quest = modConfig.QuestConfig.get(quest_id)
        if not quest:
            logger.error('==== %s ====' % '"can submit quest 不存在": %s' % quest_id)
            return
        kind = quest.get('questType')
        if not kind:
            logger.error('==== %s ====' % '"can submit quest 不能没类型": %s' % quest_id)
            return
        if kind in (modConfig.QUEST_KILL_MONSTER, modConfig.QUEST_COLLECT_ITEM,) and progress[0] >= quest['amount']:
            return True
        if kind in (modConfig.QUEST_PLAYER_LEVEL,) and progress[0] >= quest['goal']:
            return True
        if kind in (modConfig.QUEST_ARRIVE_PLACE,) and progress[0] > 0:
            return True

    def get_progress(self, player_id, quest_id):
        quest = modConfig.QuestConfig.get(quest_id)
        if not quest:
            logger.error('==== %s ====' % '"get progress quest 不存在": %s' % quest_id)
            return
        kind = quest.get('questType')
        if not kind:
            logger.error('==== %s ====' % '"get progress quest 不能没类型": %s' % quest_id)
            return
        return self.m_doing_records.get(player_id, {}).get(kind, {}).get(quest_id)

    def can_submit(self, player_id, quest_id):
        progress = self.get_progress(player_id, quest_id)
        if not progress:
            logger.info('==== %s ====' % '"can submit quest 无进度": %s' % quest_id)
            return
        return self._can_submit(quest_id, progress)

    def generate_desc(self, quest_id, progress):
        quest = modConfig.QuestConfig.get(quest_id)
        if not quest:
            logger.error('==== %s ====' % '"generate desc quest 不存在": %s' % quest_id)
            return
        kind = quest.get('questType')
        if not kind:
            logger.error('==== %s ====' % '"generate desc quest 不能没类型": %s' % quest_id)
            return
        desc = quest['desc']
        if not desc:
            desc = quest['questName']
        situation = '§r({}{}§r/{})'.format(
            self._can_submit(quest_id, progress) and '§a' or '§c',
            progress[0],
            kind in (modConfig.QUEST_KILL_MONSTER, modConfig.QUEST_COLLECT_ITEM,) and quest['amount'] or (kind == modConfig.QUEST_PLAYER_LEVEL and quest['goal'] or 1))
        pretty = desc.replace('%p', situation, 1)
        if pretty == desc:
            return desc + situation
        return pretty

    def push_quest(self, player_id):
        quest_data = self.m_doing_records.get(player_id, {})
        event_data = self.CreateEventData()
        details = reduce(lambda x, y: x + y, map(lambda kind: [(
            self.generate_desc(quest_id, progress), progress, 0 if self._can_submit(quest_id, progress) else 1
        ) for quest_id, progress in quest_data[kind].iteritems()], quest_data) or [[]])
        details.sort(key=lambda t: (t[2], t[1][-1]))  # 感觉要优化每次推都查可能不好
        event_data['progresses'] = map(lambda t: (t[2], t[0]), details[:5])
        self.fill(event_data, quest_data, 'positions', modConfig.QUEST_ARRIVE_PLACE)
        self.NotifyToClient(player_id, modConfig.DisplayQuestEvent, event_data)
        pre = self.m_player_attentive_items.get(player_id)
        self.fill(self.m_player_attentive_items, quest_data, player_id, modConfig.QUEST_COLLECT_ITEM)
        if pre != self.m_player_attentive_items.get(player_id):
            self.m_player_attentive_holding_dict.setdefault(player_id, {}).clear()

    def fill(self, event_data, quest_data, key, kind):
        if kind == modConfig.QUEST_ARRIVE_PLACE:
            event_data[key] = {quest_id: {
                'spot': modConfig.QuestConfig[quest_id]['spot'],
                'radius': modConfig.QuestConfig[quest_id]['radius']
            } for quest_id, progress in quest_data.get(kind, {}).iteritems() if not self._can_submit(quest_id, progress)}
        elif kind == modConfig.QUEST_COLLECT_ITEM:
            event_data[key] = {reduce(lambda x, y: '{}:{}'.format(x, y), modConfig.QuestConfig[quest_id]['questItemType']) for quest_id in quest_data.get(kind, {})}
        if not event_data[key]:
            del event_data[key]

    def notify(self, player_id, msg):
        if not msg:
            return
        comp = self.CreateComponent(player_id, modConfig.Minecraft, modConfig.CommandComponent)
        # comp.SetCommand("title @s title %s" % msg, player_id)
        comp.SetCommand('tellraw @s {"rawtext": [{"text": "%s"}]}' % msg, player_id)
