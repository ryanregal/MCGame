# -*- coding: utf-8 -*-
compId = "Quest"
dataDict = {
	"2d6e0e00-c8eb-443c-8c8a-9187218414d8": {
		"amount": 1,
		"cost": False,
		"desc": "",
		"goal": 1,
		"limit": 1,
		"npcEntityId": "",
		"preconditions": {
			"lv": 0,
			"preQuest": "",
			"stuff": []
		},
		"questItemType": ('minecraft:apple', 0),
		"questMobType": "minecraft:chicken",
		"questName": "任务1",
		"questType": 1,
		"radius": 0,
		"rewards": {
			"drugs": [],
			"exp": 0
		},
		"spot": "None",
		"uuid": "2d6e0e00-c8eb-443c-8c8a-9187218414d8"
	}
}
isUnique = False
name = "<property object at 0x11BAAC00>"
scriptFolderName = "script_Quest"
