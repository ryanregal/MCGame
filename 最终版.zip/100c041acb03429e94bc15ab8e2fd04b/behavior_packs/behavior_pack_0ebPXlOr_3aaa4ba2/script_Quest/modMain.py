# -*- coding: utf-8 -*-

import editorConfig
import mod.server.extraServerApi as serverApi
from mod.common.mod import Mod
from modCommon import questConfig as modConfig

from . import logger


@Mod.Binding(name=modConfig.ModName, version=modConfig.ModVersion)
class QuestMod(object):
    def __init__(self):
        logger.info("==== init QuestMod ====")

    @Mod.InitServer()
    def QuestServerInit(self):
        logger.info("==== init QuestServer ====")
        serverApi.RegisterSystem(modConfig.ModName, modConfig.ServerSystemName, editorConfig.scriptFolderName + '.' + modConfig.ServerSystemClsPath)

    @Mod.DestroyServer()
    def QuestServerDestroy(self):
        logger.info("==== destroy QuestServer ====")
